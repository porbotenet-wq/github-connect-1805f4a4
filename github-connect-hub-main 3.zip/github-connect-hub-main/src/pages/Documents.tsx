import { useNavigate } from 'react-router-dom';

export default function Documents() {
  const navigate = useNavigate();

  return (
    <div className="p-4">
      <h1 className="text-xl font-bold mb-4 text-[var(--tg-theme-text-color,#e0e0e0)]">📁 Документы</h1>

      <div className="text-center py-12">
        <div className="text-4xl mb-3">📁</div>
        <div className="text-[var(--tg-theme-text-color,#e0e0e0)] mb-2">Раздел в разработке</div>
        <div className="text-xs text-[var(--tg-theme-hint-color,#999)] mb-4">
          Функционал загрузки и управления документами будет доступен в следующем обновлении
        </div>
        <button
          onClick={() => navigate('/')}
          className="text-sm text-[var(--tg-theme-link-color,#3b82f6)]"
        >
          ← На главную
        </button>
      </div>
    </div>
  );
}
