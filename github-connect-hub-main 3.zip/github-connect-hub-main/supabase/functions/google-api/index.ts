import "https://deno.land/x/xhr@0.1.0/mod.ts";
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

interface GoogleAuth {
  access_token: string;
  expires_at: number;
}

let cachedAuth: GoogleAuth | null = null;

async function getAccessToken(): Promise<string> {
  if (cachedAuth && cachedAuth.expires_at > Date.now() + 60000) {
    return cachedAuth.access_token;
  }

  const serviceAccountJson = Deno.env.get('GOOGLE_SERVICE_ACCOUNT_KEY');
  if (!serviceAccountJson) {
    throw new Error('GOOGLE_SERVICE_ACCOUNT_KEY is not configured');
  }

  const sa = JSON.parse(serviceAccountJson);
  
  // Create JWT for Google OAuth2
  const header = { alg: 'RS256', typ: 'JWT' };
  const now = Math.floor(Date.now() / 1000);
  const claim = {
    iss: sa.client_email,
    scope: 'https://www.googleapis.com/auth/spreadsheets https://www.googleapis.com/auth/documents https://www.googleapis.com/auth/drive',
    aud: 'https://oauth2.googleapis.com/token',
    exp: now + 3600,
    iat: now,
  };

  const encoder = new TextEncoder();
  
  function base64url(data: Uint8Array): string {
    let binary = '';
    for (const byte of data) binary += String.fromCharCode(byte);
    return btoa(binary).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  const headerB64 = base64url(encoder.encode(JSON.stringify(header)));
  const claimB64 = base64url(encoder.encode(JSON.stringify(claim)));
  const signInput = `${headerB64}.${claimB64}`;

  // Import private key and sign
  const pemContent = sa.private_key
    .replace(/-----BEGIN PRIVATE KEY-----/g, '')
    .replace(/-----END PRIVATE KEY-----/g, '')
    .replace(/\s/g, '');
  
  const binaryKey = Uint8Array.from(atob(pemContent), c => c.charCodeAt(0));
  
  const cryptoKey = await crypto.subtle.importKey(
    'pkcs8',
    binaryKey,
    { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' },
    false,
    ['sign']
  );

  const signature = await crypto.subtle.sign(
    'RSASSA-PKCS1-v1_5',
    cryptoKey,
    encoder.encode(signInput)
  );

  const jwt = `${signInput}.${base64url(new Uint8Array(signature))}`;

  // Exchange JWT for access token
  const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: `grant_type=urn:ietf:params:oauth:grant-type:jwt-bearer&assertion=${jwt}`,
  });

  if (!tokenRes.ok) {
    const errText = await tokenRes.text();
    throw new Error(`Google OAuth failed [${tokenRes.status}]: ${errText}`);
  }

  const tokenData = await tokenRes.json();
  cachedAuth = {
    access_token: tokenData.access_token,
    expires_at: Date.now() + (tokenData.expires_in * 1000),
  };

  return cachedAuth.access_token;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { action, ...params } = await req.json();
    const token = await getAccessToken();

    let result: any;

    switch (action) {
      // ===== SHEETS =====
      case 'sheets.read': {
        const { spreadsheetId, range } = params;
        const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}`;
        const res = await fetch(url, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) throw new Error(`Sheets read failed [${res.status}]: ${await res.text()}`);
        result = await res.json();
        break;
      }

      case 'sheets.write': {
        const { spreadsheetId, range, values } = params;
        const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}?valueInputOption=USER_ENTERED`;
        const res = await fetch(url, {
          method: 'PUT',
          headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ values }),
        });
        if (!res.ok) throw new Error(`Sheets write failed [${res.status}]: ${await res.text()}`);
        result = await res.json();
        break;
      }

      case 'sheets.create': {
        const { title } = params;
        const res = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ properties: { title } }),
        });
        if (!res.ok) throw new Error(`Sheets create failed [${res.status}]: ${await res.text()}`);
        result = await res.json();
        break;
      }

      // ===== DOCS =====
      case 'docs.create': {
        const { title, body: docBody } = params;
        // Create doc
        const createRes = await fetch('https://docs.googleapis.com/v1/documents', {
          method: 'POST',
          headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ title }),
        });
        if (!createRes.ok) throw new Error(`Docs create failed [${createRes.status}]: ${await createRes.text()}`);
        const doc = await createRes.json();

        // Insert content if provided
        if (docBody) {
          const requests = docBody.map((item: any, idx: number) => {
            if (item.type === 'paragraph') {
              return {
                insertText: {
                  location: { index: idx === 0 ? 1 : undefined, segmentId: '' },
                  endOfSegmentLocation: idx > 0 ? { segmentId: '' } : undefined,
                  text: item.text + '\n',
                },
              };
            }
            return null;
          }).filter(Boolean);

          if (requests.length > 0) {
            // Simplified: insert all text at once
            const fullText = docBody.map((item: any) => item.text).join('\n') + '\n';
            await fetch(`https://docs.googleapis.com/v1/documents/${doc.documentId}:batchUpdate`, {
              method: 'POST',
              headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
              body: JSON.stringify({
                requests: [{ insertText: { location: { index: 1 }, text: fullText } }],
              }),
            });
          }
        }

        result = { documentId: doc.documentId, title: doc.title };
        break;
      }

      case 'docs.read': {
        const { documentId } = params;
        const res = await fetch(`https://docs.googleapis.com/v1/documents/${documentId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) throw new Error(`Docs read failed [${res.status}]: ${await res.text()}`);
        result = await res.json();
        break;
      }

      // ===== DRIVE =====
      case 'drive.list': {
        const { folderId, query } = params;
        let q = folderId ? `'${folderId}' in parents` : '';
        if (query) q += (q ? ' and ' : '') + query;
        const url = `https://www.googleapis.com/drive/v3/files?q=${encodeURIComponent(q)}&fields=files(id,name,mimeType,size,modifiedTime,webViewLink)`;
        const res = await fetch(url, {
          headers: { Authorization: `Bearer ${token}` },
        });
        if (!res.ok) throw new Error(`Drive list failed [${res.status}]: ${await res.text()}`);
        result = await res.json();
        break;
      }

      case 'drive.upload': {
        const { name, mimeType, content, folderId } = params;
        const metadata: any = { name, mimeType };
        if (folderId) metadata.parents = [folderId];

        const boundary = 'boundary_' + Date.now();
        const body = `--${boundary}\r\nContent-Type: application/json\r\n\r\n${JSON.stringify(metadata)}\r\n--${boundary}\r\nContent-Type: ${mimeType}\r\n\r\n${content}\r\n--${boundary}--`;

        const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,webViewLink', {
          method: 'POST',
          headers: {
            Authorization: `Bearer ${token}`,
            'Content-Type': `multipart/related; boundary=${boundary}`,
          },
          body,
        });
        if (!res.ok) throw new Error(`Drive upload failed [${res.status}]: ${await res.text()}`);
        result = await res.json();
        break;
      }

      default:
        throw new Error(`Unknown action: ${action}`);
    }

    return new Response(JSON.stringify({ success: true, data: result }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error: any) {
    console.error('Google API error:', error);
    return new Response(JSON.stringify({ success: false, error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
