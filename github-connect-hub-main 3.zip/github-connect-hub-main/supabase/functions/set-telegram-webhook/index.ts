const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const BOT_TOKEN = Deno.env.get('TELEGRAM_BOT_TOKEN');
  if (!BOT_TOKEN) {
    return new Response(JSON.stringify({ error: 'TELEGRAM_BOT_TOKEN not set' }), {
      status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
  const webhookUrl = `${SUPABASE_URL}/functions/v1/telegram-webhook`;

  // First check if token is valid
  const meRes = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/getMe`);
  const meData = await meRes.json();

  if (!meData.ok) {
    return new Response(JSON.stringify({ 
      error: 'Invalid bot token', 
      telegram_response: meData,
      hint: 'Please update TELEGRAM_BOT_TOKEN with a valid token from @BotFather'
    }), {
      status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }

  // Set webhook
  const res = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/setWebhook`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ url: webhookUrl }),
  });
  const data = await res.json();

  return new Response(JSON.stringify({ 
    bot: meData.result,
    webhook: data,
    webhook_url: webhookUrl,
  }), {
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
});
