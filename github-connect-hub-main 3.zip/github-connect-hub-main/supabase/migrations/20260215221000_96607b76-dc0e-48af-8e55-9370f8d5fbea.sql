
-- ==========================================
-- 1. PROJECTS
-- ==========================================
CREATE TABLE public.projects (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Projects are readable by all" ON public.projects FOR SELECT USING (true);
CREATE POLICY "Projects are insertable by all" ON public.projects FOR INSERT WITH CHECK (true);
CREATE POLICY "Projects are updatable by all" ON public.projects FOR UPDATE USING (true);

-- ==========================================
-- 2. USERS (profiles)
-- ==========================================
CREATE TABLE public.users (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  telegram_id BIGINT UNIQUE,
  full_name TEXT NOT NULL DEFAULT '',
  role TEXT NOT NULL DEFAULT 'WORKER',
  department TEXT,
  status TEXT NOT NULL DEFAULT 'PENDING',
  project_id UUID REFERENCES public.projects(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users are readable by all" ON public.users FOR SELECT USING (true);
CREATE POLICY "Users are insertable by all" ON public.users FOR INSERT WITH CHECK (true);
CREATE POLICY "Users are updatable by all" ON public.users FOR UPDATE USING (true);

-- ==========================================
-- 3. CONSTRUCTION OBJECTS
-- ==========================================
CREATE TABLE public.construction_objects (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  project_id UUID NOT NULL REFERENCES public.projects(id),
  created_by UUID REFERENCES public.users(id),
  name TEXT NOT NULL,
  customer_name TEXT DEFAULT '',
  customer_address TEXT DEFAULT '',
  customer_contacts TEXT DEFAULT '',
  contractor_name TEXT DEFAULT '',
  work_types TEXT[] DEFAULT '{}',
  total_volume_m2 NUMERIC DEFAULT 0,
  start_date DATE,
  end_date DATE,
  duration_days INT,
  status TEXT NOT NULL DEFAULT 'NEW',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.construction_objects ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Objects are readable by all" ON public.construction_objects FOR SELECT USING (true);
CREATE POLICY "Objects are insertable by all" ON public.construction_objects FOR INSERT WITH CHECK (true);
CREATE POLICY "Objects are updatable by all" ON public.construction_objects FOR UPDATE USING (true);
CREATE POLICY "Objects are deletable by all" ON public.construction_objects FOR DELETE USING (true);

-- ==========================================
-- 4. WORK SCHEDULE ITEMS (ГПР)
-- ==========================================
CREATE TABLE public.work_schedule_items (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  object_id UUID NOT NULL REFERENCES public.construction_objects(id) ON DELETE CASCADE,
  sort_order INT NOT NULL DEFAULT 0,
  section TEXT NOT NULL DEFAULT '',
  subsection TEXT DEFAULT '',
  work_name TEXT NOT NULL,
  unit TEXT DEFAULT '',
  volume_plan NUMERIC DEFAULT 0,
  volume_fact NUMERIC DEFAULT 0,
  start_date DATE,
  end_date DATE,
  duration_days INT,
  workers_count INT DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'PLANNED',
  notes TEXT DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.work_schedule_items ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Schedule items readable by all" ON public.work_schedule_items FOR SELECT USING (true);
CREATE POLICY "Schedule items insertable by all" ON public.work_schedule_items FOR INSERT WITH CHECK (true);
CREATE POLICY "Schedule items updatable by all" ON public.work_schedule_items FOR UPDATE USING (true);
CREATE POLICY "Schedule items deletable by all" ON public.work_schedule_items FOR DELETE USING (true);

-- ==========================================
-- 5. FACADES (фасады объекта)
-- ==========================================
CREATE TABLE public.facades (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  object_id UUID NOT NULL REFERENCES public.construction_objects(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  modules_plan INT DEFAULT 0,
  modules_fact INT DEFAULT 0,
  brackets_plan INT DEFAULT 0,
  brackets_fact INT DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'NOT_STARTED',
  sort_order INT DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.facades ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Facades readable by all" ON public.facades FOR SELECT USING (true);
CREATE POLICY "Facades insertable by all" ON public.facades FOR INSERT WITH CHECK (true);
CREATE POLICY "Facades updatable by all" ON public.facades FOR UPDATE USING (true);
CREATE POLICY "Facades deletable by all" ON public.facades FOR DELETE USING (true);

-- ==========================================
-- 6. FLOOR SCHEMAS (поэтажные схемы)
-- ==========================================
CREATE TABLE public.floor_schemas (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  facade_id UUID NOT NULL REFERENCES public.facades(id) ON DELETE CASCADE,
  floor_number INT NOT NULL,
  elevation TEXT DEFAULT '',
  cells JSONB DEFAULT '[]',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.floor_schemas ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Floor schemas readable by all" ON public.floor_schemas FOR SELECT USING (true);
CREATE POLICY "Floor schemas insertable by all" ON public.floor_schemas FOR INSERT WITH CHECK (true);
CREATE POLICY "Floor schemas updatable by all" ON public.floor_schemas FOR UPDATE USING (true);

-- ==========================================
-- 7. PLAN FACT DAILY (ежедневный план-факт)
-- ==========================================
CREATE TABLE public.plan_fact_daily (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  object_id UUID NOT NULL REFERENCES public.construction_objects(id) ON DELETE CASCADE,
  report_date DATE NOT NULL,
  day_number INT,
  week TEXT,
  modules_plan NUMERIC DEFAULT 0,
  modules_fact NUMERIC DEFAULT 0,
  brackets_plan NUMERIC DEFAULT 0,
  brackets_fact NUMERIC DEFAULT 0,
  sealant_plan NUMERIC DEFAULT 0,
  sealant_fact NUMERIC DEFAULT 0,
  hermetic_plan NUMERIC DEFAULT 0,
  hermetic_fact NUMERIC DEFAULT 0,
  notes TEXT DEFAULT '',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE(object_id, report_date)
);
ALTER TABLE public.plan_fact_daily ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Plan fact readable by all" ON public.plan_fact_daily FOR SELECT USING (true);
CREATE POLICY "Plan fact insertable by all" ON public.plan_fact_daily FOR INSERT WITH CHECK (true);
CREATE POLICY "Plan fact updatable by all" ON public.plan_fact_daily FOR UPDATE USING (true);

-- ==========================================
-- 8. ECOSYSTEM TASKS (задачи экосистемы)
-- ==========================================
CREATE TABLE public.ecosystem_tasks (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  object_id UUID NOT NULL REFERENCES public.construction_objects(id) ON DELETE CASCADE,
  task_number INT NOT NULL,
  block TEXT NOT NULL DEFAULT '',
  department TEXT NOT NULL DEFAULT '',
  code TEXT NOT NULL DEFAULT '',
  task_name TEXT NOT NULL,
  responsible TEXT DEFAULT '',
  incoming_doc TEXT DEFAULT '',
  outgoing_doc TEXT DEFAULT '',
  recipient TEXT DEFAULT '',
  duration_days INT DEFAULT 0,
  planned_date DATE,
  bot_trigger TEXT DEFAULT '',
  notification_type TEXT DEFAULT '',
  dependency_ids TEXT DEFAULT '',
  priority TEXT NOT NULL DEFAULT 'Средний',
  status TEXT NOT NULL DEFAULT 'Ожидание',
  assigned_user_id UUID REFERENCES public.users(id),
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.ecosystem_tasks ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Tasks readable by all" ON public.ecosystem_tasks FOR SELECT USING (true);
CREATE POLICY "Tasks insertable by all" ON public.ecosystem_tasks FOR INSERT WITH CHECK (true);
CREATE POLICY "Tasks updatable by all" ON public.ecosystem_tasks FOR UPDATE USING (true);
CREATE POLICY "Tasks deletable by all" ON public.ecosystem_tasks FOR DELETE USING (true);

-- ==========================================
-- 9. KPI SNAPSHOTS (ключевые показатели)
-- ==========================================
CREATE TABLE public.kpi_snapshots (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  object_id UUID NOT NULL REFERENCES public.construction_objects(id) ON DELETE CASCADE,
  indicator_name TEXT NOT NULL,
  unit TEXT DEFAULT '',
  value_plan NUMERIC DEFAULT 0,
  value_fact NUMERIC DEFAULT 0,
  deviation NUMERIC DEFAULT 0,
  percent_done NUMERIC DEFAULT 0,
  snapshot_date DATE NOT NULL DEFAULT CURRENT_DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.kpi_snapshots ENABLE ROW LEVEL SECURITY;
CREATE POLICY "KPI readable by all" ON public.kpi_snapshots FOR SELECT USING (true);
CREATE POLICY "KPI insertable by all" ON public.kpi_snapshots FOR INSERT WITH CHECK (true);
CREATE POLICY "KPI updatable by all" ON public.kpi_snapshots FOR UPDATE USING (true);

-- ==========================================
-- 10. AUDIT LOGS
-- ==========================================
CREATE TABLE public.audit_logs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL DEFAULT '',
  entity_id UUID,
  user_id UUID REFERENCES public.users(id),
  old_value JSONB,
  new_value JSONB,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Audit logs readable by all" ON public.audit_logs FOR SELECT USING (true);
CREATE POLICY "Audit logs insertable by all" ON public.audit_logs FOR INSERT WITH CHECK (true);

-- ==========================================
-- 11. TECH INSPECTION (сдача технадзору)
-- ==========================================
CREATE TABLE public.tech_inspections (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  object_id UUID NOT NULL REFERENCES public.construction_objects(id) ON DELETE CASCADE,
  stage_name TEXT NOT NULL,
  total_count INT DEFAULT 0,
  accepted_count INT DEFAULT 0,
  pending_count INT DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.tech_inspections ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Inspections readable by all" ON public.tech_inspections FOR SELECT USING (true);
CREATE POLICY "Inspections insertable by all" ON public.tech_inspections FOR INSERT WITH CHECK (true);
CREATE POLICY "Inspections updatable by all" ON public.tech_inspections FOR UPDATE USING (true);

-- ==========================================
-- TRIGGER: auto-update updated_at
-- ==========================================
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_projects_updated_at BEFORE UPDATE ON public.projects FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_objects_updated_at BEFORE UPDATE ON public.construction_objects FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_schedule_updated_at BEFORE UPDATE ON public.work_schedule_items FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_floor_schemas_updated_at BEFORE UPDATE ON public.floor_schemas FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_tasks_updated_at BEFORE UPDATE ON public.ecosystem_tasks FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
CREATE TRIGGER update_inspections_updated_at BEFORE UPDATE ON public.tech_inspections FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();
