
-- Add contract fields to construction_objects
ALTER TABLE public.construction_objects
  ADD COLUMN IF NOT EXISTS contract_date date DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS contract_link text DEFAULT '' NOT NULL,
  ADD COLUMN IF NOT EXISTS estimate_link text DEFAULT '' NOT NULL,
  ADD COLUMN IF NOT EXISTS project_manager text DEFAULT '' NOT NULL;
