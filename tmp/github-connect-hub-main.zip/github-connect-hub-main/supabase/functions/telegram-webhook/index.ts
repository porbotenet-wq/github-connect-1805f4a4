const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version',
};

const BOT_TOKEN = Deno.env.get('TELEGRAM_BOT_TOKEN')!;
const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SUPABASE_SERVICE_ROLE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const MINI_APP_URL = Deno.env.get('MINI_APP_URL') || 'https://id-preview--2a8cc57f-31d4-4a33-aea4-b3f4c74d21e9.lovable.app';

// ─── Telegram API helpers ───
async function sendMessage(chatId: number, text: string, options: any = {}) {
  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ chat_id: chatId, text, parse_mode: 'HTML', ...options }),
  });
}

async function answerCallbackQuery(callbackQueryId: string, text?: string) {
  await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/answerCallbackQuery`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ callback_query_id: callbackQueryId, text }),
  });
}

// ─── Supabase REST helpers (using service role for full access) ───
async function dbSelect(path: string) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${path}`, {
    headers: {
      'apikey': SUPABASE_SERVICE_ROLE_KEY,
      'Authorization': `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
      'Accept': 'application/json',
    },
  });
  return res.json();
}

async function dbInsert(table: string, data: any) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}`, {
    method: 'POST',
    headers: {
      'apikey': SUPABASE_SERVICE_ROLE_KEY,
      'Authorization': `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
      'Content-Type': 'application/json',
      'Prefer': 'return=representation',
    },
    body: JSON.stringify(data),
  });
  return res.json();
}

async function dbPatch(table: string, filter: string, data: any) {
  const res = await fetch(`${SUPABASE_URL}/rest/v1/${table}?${filter}`, {
    method: 'PATCH',
    headers: {
      'apikey': SUPABASE_SERVICE_ROLE_KEY,
      'Authorization': `Bearer ${SUPABASE_SERVICE_ROLE_KEY}`,
      'Content-Type': 'application/json',
      'Prefer': 'return=representation',
    },
    body: JSON.stringify(data),
  });
  return res.json();
}

// ─── Data fetchers ───
async function getUser(telegramId: number) {
  const data = await dbSelect(`users?select=*&telegram_id=eq.${telegramId}`);
  return data?.[0] || null;
}

async function getProject() {
  const data = await dbSelect(`projects?select=*&limit=1&order=created_at.desc`);
  return data?.[0] || null;
}

async function getObjectsForProject(projectId: string) {
  return await dbSelect(`construction_objects?select=id,name,status,project_manager&project_id=eq.${projectId}&order=created_at.desc&limit=10`) || [];
}

async function getTaskStats(objectId: string) {
  const data = await dbSelect(`ecosystem_tasks?select=status,block&object_id=eq.${objectId}`);
  const stats: Record<string, number> = {};
  const blocks: Record<string, { total: number; done: number }> = {};
  (data || []).forEach((t: any) => {
    stats[t.status] = (stats[t.status] || 0) + 1;
    if (!blocks[t.block]) blocks[t.block] = { total: 0, done: 0 };
    blocks[t.block].total++;
    if (t.status === 'Выполнена') blocks[t.block].done++;
  });
  return { stats, blocks, total: data?.length || 0 };
}

async function getMyTasks(objectId: string, department: string) {
  return await dbSelect(
    `ecosystem_tasks?select=*&object_id=eq.${objectId}&department=eq.${encodeURIComponent(department)}&status=in.(Ожидание,В работе)&order=task_number.asc&limit=15`
  ) || [];
}

async function getOverdueTasks(objectId: string) {
  const today = new Date().toISOString().split('T')[0];
  return await dbSelect(
    `ecosystem_tasks?select=*&object_id=eq.${objectId}&status=in.(Ожидание,В работе)&planned_date=lt.${today}&order=planned_date.asc&limit=10`
  ) || [];
}

// ─── Status helpers ───
const STATUS_EMOJI: Record<string, string> = {
  'Ожидание': '⚪', 'В работе': '🟢', 'Выполнена': '✅', 'Заблокирована': '🚫',
};

const BLOCK_EMOJI: Record<string, string> = {
  'Договорной этап': '📝', 'Запуск проекта': '🚀', 'Проектные работы': '📐',
  'Снабжение': '📦', 'Производство': '🏭', 'Монтаж': '🔧', 'ПТО': '📋', 'Контроль': '🎯',
};

function makeProgressBar(pct: number): string {
  const filled = Math.round(pct / 10);
  return '▓'.repeat(filled) + '░'.repeat(10 - filled);
}

// ─── Auto-registration ───
async function autoRegister(telegramId: number, from: any) {
  const fullName = [from.first_name, from.last_name].filter(Boolean).join(' ') || 'User';
  const project = await getProject();
  const result = await dbInsert('users', {
    telegram_id: telegramId,
    full_name: fullName,
    status: 'PENDING',
    role: 'WORKER',
    project_id: project?.id || null,
  });
  return result?.[0] || result;
}

// ─── Command handlers ───
async function handleCommand(chatId: number, text: string, telegramId: number, from: any) {
  const user = await getUser(telegramId);

  if (!user) {
    const registered = await autoRegister(telegramId, from);
    if (registered) {
      await sendMessage(chatId,
        `✅ <b>Добро пожаловать, ${from.first_name}!</b>\n\n` +
        `Ваша заявка отправлена и ожидает активации администратором.\n` +
        `Используйте /start для проверки статуса.`
      );
    } else {
      await sendMessage(chatId, '❌ Ошибка при регистрации. Попробуйте позже.');
    }
    return;
  }

  if (user.status === 'PENDING') {
    await sendMessage(chatId, '⏳ Ваша заявка на рассмотрении. Ожидайте активации администратором.');
    return;
  }
  if (user.status === 'BLOCKED') {
    await sendMessage(chatId, '🚫 Ваш аккаунт заблокирован.');
    return;
  }

  const project = await getProject();

  switch (text) {
    case '/start': {
      const keyboard = {
        reply_markup: {
          inline_keyboard: [
            [{ text: '📊 Сводка', callback_data: 'status' }, { text: '📋 Мои задачи', callback_data: 'my_tasks' }],
            [{ text: '🏗 Объекты', callback_data: 'objects' }, { text: '⚠️ Просроченные', callback_data: 'overdue' }],
            [{ text: '🚀 Открыть приложение', web_app: { url: MINI_APP_URL } }],
          ],
        },
      };
      await sendMessage(chatId,
        `👋 Добро пожаловать, <b>${user.full_name}</b>!\n\n` +
        `🔑 Роль: <b>${user.role}</b>\n` +
        (user.department ? `🏢 Отдел: <b>${user.department}</b>\n` : '') +
        (project ? `🏗 Проект: <b>${project.name}</b>\n` : '') +
        `\nВыберите действие:`,
        keyboard
      );
      break;
    }

    case '/objects': {
      if (!project) { await sendMessage(chatId, '❌ Проект не найден.'); return; }
      const objects = await getObjectsForProject(project.id);
      if (objects.length === 0) {
        await sendMessage(chatId, '🏗 Объекты не найдены.');
        return;
      }
      let msg = `🏗 <b>Объекты (${objects.length})</b>\n\n`;
      const buttons: any[][] = [];
      objects.forEach((o: any, i: number) => {
        const statusEmoji = o.status === 'NEW' ? '🆕' : o.status === 'IN_PROGRESS' ? '🟢' : o.status === 'COMPLETED' ? '✅' : '⚪';
        msg += `${statusEmoji} <b>${i + 1}. ${o.name}</b>\n`;
        if (o.project_manager) msg += `   👷 РП: ${o.project_manager}\n`;
        buttons.push([{ text: `📊 ${o.name.substring(0, 30)}`, callback_data: `obj_${o.id.substring(0, 30)}` }]);
      });
      buttons.push([{ text: '🚀 Открыть в приложении', web_app: { url: `${MINI_APP_URL}?startapp=objects` } }]);
      await sendMessage(chatId, msg, { reply_markup: { inline_keyboard: buttons } });
      break;
    }

    case '/status': {
      if (!project) { await sendMessage(chatId, '❌ Проект не найден.'); return; }
      const objects = await getObjectsForProject(project.id);
      if (objects.length === 0) {
        await sendMessage(chatId, '📊 Нет объектов для сводки.');
        return;
      }

      let msg = `📊 <b>Сводка: ${project.name}</b>\n\n`;
      for (const obj of objects.slice(0, 5)) {
        const { stats, blocks, total } = await getTaskStats(obj.id);
        const done = stats['Выполнена'] || 0;
        const pct = total > 0 ? Math.round((done / total) * 100) : 0;
        msg += `🏗 <b>${obj.name}</b>\n`;
        msg += `${makeProgressBar(pct)} <b>${pct}%</b> (${done}/${total})\n`;
        for (const [block, info] of Object.entries(blocks)) {
          const bPct = info.total > 0 ? Math.round((info.done / info.total) * 100) : 0;
          msg += `  ${BLOCK_EMOJI[block] || '•'} ${block}: ${bPct}% (${info.done}/${info.total})\n`;
        }
        msg += '\n';
      }

      await sendMessage(chatId, msg, {
        reply_markup: { inline_keyboard: [[{ text: '🚀 Подробнее', web_app: { url: MINI_APP_URL } }]] },
      });
      break;
    }

    case '/tasks':
    case '/my_tasks': {
      if (!project) { await sendMessage(chatId, '❌ Проект не найден.'); return; }
      const objects = await getObjectsForProject(project.id);
      if (objects.length === 0) { await sendMessage(chatId, '📋 Нет объектов.'); return; }

      const department = user.department || user.role || '';
      let msg = `📋 <b>Мои задачи</b> (${department})\n\n`;
      const buttons: any[][] = [];

      for (const obj of objects.slice(0, 3)) {
        const tasks = await getMyTasks(obj.id, department);
        if (tasks.length === 0) continue;
        msg += `🏗 <b>${obj.name}</b>\n`;
        tasks.forEach((t: any) => {
          const emoji = STATUS_EMOJI[t.status] || '•';
          const deadline = t.planned_date ? ` → ${t.planned_date}` : '';
          msg += `${emoji} ${t.task_name.substring(0, 60)}${deadline}\n`;
          if (t.status === 'Ожидание') {
            buttons.push([{ text: `▶ Начать: ${t.task_name.substring(0, 25)}`, callback_data: `tstart_${t.id.substring(0, 28)}` }]);
          } else if (t.status === 'В работе') {
            buttons.push([{ text: `✅ Готово: ${t.task_name.substring(0, 25)}`, callback_data: `tdone_${t.id.substring(0, 29)}` }]);
          }
        });
        msg += '\n';
      }

      if (buttons.length === 0) msg += 'Нет активных задач для вашего отдела 👍\n';
      buttons.push([{ text: '📋 Все задачи', web_app: { url: `${MINI_APP_URL}?startapp=tasks` } }]);
      await sendMessage(chatId, msg, { reply_markup: { inline_keyboard: buttons } });
      break;
    }

    case '/overdue': {
      if (!project) { await sendMessage(chatId, '❌ Проект не найден.'); return; }
      const objects = await getObjectsForProject(project.id);
      let msg = `⚠️ <b>Просроченные задачи</b>\n\n`;
      let totalOverdue = 0;

      for (const obj of objects.slice(0, 5)) {
        const overdue = await getOverdueTasks(obj.id);
        if (overdue.length === 0) continue;
        totalOverdue += overdue.length;
        msg += `🏗 <b>${obj.name}</b>\n`;
        overdue.forEach((t: any) => {
          const days = Math.ceil((Date.now() - new Date(t.planned_date).getTime()) / 86400000);
          msg += `🔴 ${t.task_name.substring(0, 50)} (<b>-${days}д</b>)\n`;
          msg += `   ${BLOCK_EMOJI[t.block] || ''} ${t.block} | ${t.department}\n`;
        });
        msg += '\n';
      }

      if (totalOverdue === 0) msg = '✅ Нет просроченных задач! Отличная работа 👏';
      await sendMessage(chatId, msg);
      break;
    }

    case '/users': {
      const allUsers = await dbSelect('users?select=id,full_name,status,role,department,telegram_id&order=created_at.desc&limit=20') || [];
      if (allUsers.length === 0) { await sendMessage(chatId, '👥 Нет пользователей.'); break; }
      let msg = '👥 <b>Пользователи</b>\n\n';
      const buttons: any[][] = [];
      allUsers.forEach((u: any, i: number) => {
        const st = u.status === 'PENDING' ? '⏳' : u.status === 'ACTIVE' ? '✅' : '🚫';
        msg += `${st} <b>${u.full_name}</b> — ${u.role}${u.department ? ` (${u.department})` : ''}\n`;
        if (u.status === 'PENDING') {
          buttons.push([{ text: `✅ Одобрить: ${u.full_name.substring(0, 25)}`, callback_data: `approve_${u.id.substring(0, 27)}` }]);
        }
      });
      if (buttons.length === 0) msg += '\nНет ожидающих заявок 👍';
      buttons.push([{ text: '👥 Открыть в приложении', web_app: { url: `${MINI_APP_URL}?startapp=admin` } }]);
      await sendMessage(chatId, msg, { reply_markup: { inline_keyboard: buttons } });
      break;
    }

    case '/help': {
      await sendMessage(chatId,
        `ℹ️ <b>Команды STSphera</b>\n\n` +
        `/start — Главное меню\n` +
        `/status — Сводка по объектам\n` +
        `/objects — Список объектов\n` +
        `/tasks — Мои задачи\n` +
        `/overdue — Просроченные задачи\n` +
        `/users — Управление пользователями\n` +
        `/help — Справка\n\n` +
        `💡 Управляйте задачами прямо из бота!`
      );
      break;
    }

    default:
      await sendMessage(chatId, 'Я не понимаю эту команду 🤔\n\nИспользуйте /start или /help');
  }
}

// ─── Callback query handler ───
async function handleCallbackQuery(callbackQuery: any) {
  const chatId = callbackQuery.message?.chat?.id;
  const data = callbackQuery.data;
  const telegramId = callbackQuery.from.id;

  await answerCallbackQuery(callbackQuery.id);
  if (!chatId || !data) return;

  // Approve user
  if (data.startsWith('approve_')) {
    const userId = data.replace('approve_', '');
    await dbPatch('users', `id=eq.${userId}`, { status: 'ACTIVE' });
    await sendMessage(chatId, '✅ Пользователь активирован!');
    return;
  }

  // Task actions
  if (data.startsWith('tstart_')) {
    const taskId = data.replace('tstart_', '');
    await dbPatch('ecosystem_tasks', `id=eq.${taskId}`, { status: 'В работе', updated_at: new Date().toISOString() });
    const user = await getUser(telegramId);
    if (user) {
      await dbInsert('audit_logs', { action: 'TASK_STATUS_CHANGED', entity_type: 'EcosystemTask', entity_id: taskId, user_id: user.id, new_value: { status: 'В работе' } });
    }
    await sendMessage(chatId, '▶ Задача переведена в статус <b>В работе</b>!\n\nИспользуйте /tasks для обновлённого списка.');
    return;
  }

  if (data.startsWith('tdone_')) {
    const taskId = data.replace('tdone_', '');
    await dbPatch('ecosystem_tasks', `id=eq.${taskId}`, { status: 'Выполнена', updated_at: new Date().toISOString(), completed_at: new Date().toISOString() });
    const user = await getUser(telegramId);
    if (user) {
      await dbInsert('audit_logs', { action: 'TASK_STATUS_CHANGED', entity_type: 'EcosystemTask', entity_id: taskId, user_id: user.id, new_value: { status: 'Выполнена' } });
    }
    await sendMessage(chatId, '✅ Задача выполнена!\n\nИспользуйте /tasks для обновлённого списка.');
    return;
  }

  // Object details
  if (data.startsWith('obj_')) {
    const objId = data.replace('obj_', '');
    const { stats, blocks, total } = await getTaskStats(objId);
    const done = stats['Выполнена'] || 0;
    const pct = total > 0 ? Math.round((done / total) * 100) : 0;

    let msg = `📊 <b>Статистика объекта</b>\n\n`;
    msg += `${makeProgressBar(pct)} <b>${pct}%</b> (${done}/${total} задач)\n\n`;

    for (const [block, info] of Object.entries(blocks)) {
      const bPct = info.total > 0 ? Math.round((info.done / info.total) * 100) : 0;
      msg += `${BLOCK_EMOJI[block] || '•'} <b>${block}</b>: ${bPct}% (${info.done}/${info.total})\n`;
    }

    await sendMessage(chatId, msg, {
      reply_markup: { inline_keyboard: [[{ text: '🚀 Открыть', web_app: { url: `${MINI_APP_URL}?startapp=objects` } }]] },
    });
    return;
  }

  // Navigation
  const commandMap: Record<string, string> = {
    status: '/status', my_tasks: '/tasks', overdue: '/overdue', objects: '/objects',
  };
  const command = commandMap[data] || '/start';
  await handleCommand(chatId, command, telegramId, callbackQuery.from);
}

// ─── Main ───
Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const update = await req.json();

    if (update.message?.text) {
      await handleCommand(update.message.chat.id, update.message.text, update.message.from.id, update.message.from);
    } else if (update.callback_query) {
      await handleCallbackQuery(update.callback_query);
    }

    return new Response(JSON.stringify({ ok: true }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  } catch (error) {
    console.error('Webhook error:', error);
    return new Response(JSON.stringify({ error: 'Internal error' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});
